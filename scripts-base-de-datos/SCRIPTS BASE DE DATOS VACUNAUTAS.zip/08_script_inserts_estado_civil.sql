INSERT INTO estado_civil (descripcion)
VALUES('SOLTER@');

INSERT INTO estado_civil (descripcion)
VALUES('CASAD@');

INSERT INTO estado_civil (descripcion)
VALUES('DIVORCID@');

INSERT INTO estado_civil (descripcion)
VALUES('UNIÓN LIBRE');

INSERT INTO estado_civil (descripcion)
VALUES('VIUD@');