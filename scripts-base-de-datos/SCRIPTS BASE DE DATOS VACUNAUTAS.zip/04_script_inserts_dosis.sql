INSERT INTO dosis (nombre_dosis)
VALUES('ÚNICA');

INSERT INTO dosis (nombre_dosis)
VALUES('RECIÉN NACIDO');

INSERT INTO dosis (nombre_dosis)
VALUES('PRIMERA');

INSERT INTO dosis (nombre_dosis)
VALUES('SEGUNDA');

INSERT INTO dosis (nombre_dosis)
VALUES('TERCERA');

INSERT INTO dosis (nombre_dosis)
VALUES('ANUAL');

INSERT INTO dosis (nombre_dosis)
VALUES('REFUERZO');

INSERT INTO dosis (nombre_dosis)
VALUES('PRIMER REFUERZO');

INSERT INTO dosis (nombre_dosis)
VALUES('SEGUNDO REFUERZO');