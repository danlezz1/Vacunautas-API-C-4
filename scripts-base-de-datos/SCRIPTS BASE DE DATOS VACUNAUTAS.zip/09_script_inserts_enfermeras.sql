INSERT INTO enfermeras (id_estado_civil, id_institucion, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato, titulo)
VALUES(1, 1, '40013542', 'ANDRES', 'FELIPE', 'CHACÓN', 'SALAZAR', '7440882', '311 278 5565', 'KRA 7 # 34 - 89', 'afhs55@gmail.com', '1972/02/01', 'M', 3, 'ENFERMERO GENERAL');

INSERT INTO enfermeras (id_estado_civil, id_institucion, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato, titulo)
VALUES(1, 1, '40040781', 'LUZ', 'EMILIA', 'GARCÍA', 'BENAVIDEZ', '7432584', '313 845 2121', 'CALLE 30 # 40 - 25', 'legb31@gmail.com', '1968/04/25', 'F', 4, 'ENFERMERA GENERAL');

INSERT INTO enfermeras (id_estado_civil, id_institucion, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato, titulo)
VALUES(2, 1, '40042782', 'MARÍA', 'DORIS', 'CAMACHO', 'PINEDA', '7410896', '310 821 5690', 'CALLE 2 # 10 - 18', 'mdcp22@gmail.com', '1961/09/04', 'F', 4, 'ENFERMERA GENERAL');

INSERT INTO enfermeras (id_estado_civil, id_institucion, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato, titulo)
VALUES(2, 1, '40042782', 'GLORIA', 'NELLY', 'JIMENEZ', 'MONROY', '7427054', '321 343 9658', 'KRA 15 # 23 - 45', 'gnjm01@hotmail.com', '1965/03/20', 'F', 3, 'ENFERMERA TÉCNICA ESPECIALIZADA');

INSERT INTO enfermeras (id_estado_civil, id_institucion, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato, titulo)
VALUES(1, 2, '1048625534', 'ANGIE', 'PATRICIA', 'LIZCANO', 'AGUILAR', '7427651', '312 987 0231', 'KRA 1 # 34 - 23', 'apla09@hotmail.com', '1987/09/09', 'F', 3, 'ENFERMERA TÉCNICA ESPECIALIZADA');

INSERT INTO enfermeras (id_estado_civil, id_institucion, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato, titulo)
VALUES(1, 2, '1049631132', 'LIZETH', 'CAMILA', 'OCHOA', 'FORERO', '7419842', '311 395 3145', 'TRANSVERSAL 4 # 19 - 15', 'lcof20@gmail.com', '1992/09/09', 'F', 3, 'ENFERMERA TÉCNICA');

INSERT INTO enfermeras (id_estado_civil, id_institucion, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato, titulo)
VALUES(1, 3, '40078943', 'AURA', 'LILIANA', 'ROMERO', 'MOJICA', '7400654', '318 231 5672', 'KRA 8 # 18 - 02', 'alrm14@gmail.com', '1966/01/14', 'F', 3, 'ENFERMERA GENERAL');

INSERT INTO enfermeras (id_estado_civil, id_institucion, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato, titulo)
VALUES(1, 3, '40056821', 'DORA', 'CECILIA', 'MANCIPE', 'MUÑOZ', '7449642', '311 923 1120', 'CALLE 11 # 24 - 43', 'dcmm76@gmail.com', '1976/10/23', 'F', 3, 'ENFERMERA GENERAL');

INSERT INTO enfermeras (id_estado_civil, id_institucion, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato, titulo)
VALUES(1, 4, '1047532481', 'GABRIEL', 'MAURICIO', 'LLORENTE', 'BERMUDEZ', '7442565', '314 543 6322', 'KRA 17 # 34 - 04', 'gmlb11@gmail.com', '1985/06/11', 'M', 4, 'ENFERMERO TÉCNICO ESPECIALIZADO');

INSERT INTO enfermeras (id_estado_civil, id_institucion, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato, titulo)
VALUES(2, 4, '40013753', 'JULIA', 'AMELIA', 'MORENO', 'CIFUENTES', '7456789', '310 455 6677', 'CALLE 12 # 43 - 52', 'jamc31@gmail.com', '1969/08/31', 'F', 4, 'ENFERMERA GENERAL');