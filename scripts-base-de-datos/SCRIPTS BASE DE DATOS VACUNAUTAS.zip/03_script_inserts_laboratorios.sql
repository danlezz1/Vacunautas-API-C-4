INSERT INTO laboratorios (nombre_lab)
VALUES('INTERVAX');

INSERT INTO laboratorios (nombre_lab)
VALUES('SERUM');

INSERT INTO laboratorios (nombre_lab)
VALUES('SANOK');

INSERT INTO laboratorios (nombre_lab)
VALUES('LGL');

INSERT INTO laboratorios (nombre_lab)
VALUES('JEM');

INSERT INTO laboratorios (nombre_lab)
VALUES('GSK');

INSERT INTO laboratorios (nombre_lab)
VALUES('MSD');

INSERT INTO laboratorios (nombre_lab)
VALUES('TRS');