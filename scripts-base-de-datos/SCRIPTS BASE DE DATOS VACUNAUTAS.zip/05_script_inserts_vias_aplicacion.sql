INSERT INTO vias_aplicacion (nombre_via)
VALUES('ORAL');

INSERT INTO vias_aplicacion (nombre_via)
VALUES('INTRAMUSCULAR');

INSERT INTO vias_aplicacion (nombre_via)
VALUES('SUBCUTÁNEA');

INSERT INTO vias_aplicacion (nombre_via)
VALUES('INTRAVENOSA');

INSERT INTO vias_aplicacion (nombre_via)
VALUES('INTRADÉRMICA');