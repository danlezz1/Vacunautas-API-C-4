-- ENFERMERAS --

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(1, 2,'40013542', 'ANDRES', 'FELIPE', 'CHACÓN', 'SALAZAR', '311 278 5565', 'KRA 7 # 34 - 89', 'afhs55@gmail.com', '1972/02/01', 'M', 3, 'afhs55', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(1, 2, '40040781', 'LUZ', 'EMILIA', 'GARCÍA', 'BENAVIDEZ', '313 845 2121', 'CALLE 30 # 40 - 25', 'legb31@gmail.com', '1968/04/25', 'F', 4, 'legb31', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(2, 2, '40042782', 'MARÍA', 'DORIS', 'CAMACHO', 'PINEDA', '310 821 5690', 'CALLE 2 # 10 - 18', 'mdcp22@gmail.com', '1961/09/04', 'F', 4, 'mdcp22', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(2, 2, '40042951', 'GLORIA', 'NELLY', 'JIMENEZ', 'MONROY', '321 343 9658', 'KRA 15 # 23 - 45', 'gnjm01@hotmail.com', '1965/03/20', 'F', 3, 'gnjm01', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(1, 2, '1048625534', 'ANGIE', 'PATRICIA', 'LIZCANO', 'AGUILAR', '312 987 0231', 'KRA 1 # 34 - 23', 'apla09@hotmail.com', '1987/09/09', 'F', 3, 'apla09', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(1, 2, '1049631132', 'LIZETH', 'CAMILA', 'OCHOA', 'FORERO', '311 395 3145', 'TRANSVERSAL 4 # 19 - 15', 'lcof20@gmail.com', '1992/09/09', 'F', 3, 'lcof20','12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(1, 2, '40078943', 'AURA', 'LILIANA', 'ROMERO', 'MOJICA', '318 231 5672', 'KRA 8 # 18 - 02', 'alrm14@gmail.com', '1966/01/14', 'F', 3, 'alrm14', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(1, 2, '40056821', 'DORA', 'CECILIA', 'MANCIPE', 'MUÑOZ', '311 923 1120', 'CALLE 11 # 24 - 43', 'dcmm76@gmail.com', '1976/10/23', 'F', 3, 'dcmm76', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(1, 2, '1047532481', 'GABRIEL', 'MAURICIO', 'LLORENTE', 'BERMUDEZ', '314 543 6322', 'KRA 17 # 34 - 04', 'gmlb11@gmail.com', '1985/06/11', 'M', 4, 'gmlb11', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(2, 2, '40013753', 'JULIA', 'AMELIA', 'MORENO', 'CIFUENTES', '310 455 6677', 'CALLE 12 # 43 - 52', 'jamc31@gmail.com', '1969/08/31', 'F', 4, 'jamc31', '12345');

-- ACUDIENTES --

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(2, 3, '40511119', 'ELDA', 'JOHANA', 'PEDRAZA', 'AMEZQUITA', '314 516 2170', 'KRA 11 # 23 - 65', 'ejpa1@gmail.com', '1980/11/01', 'F', 2, 'ejpa1', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(1, 3, '40213134', 'CARMEN', 'ROSA', 'FONSECA', 'CANO', '311 506 3539', 'CALLE 2 # 11 - 34', 'crfc23@gmail.com', '1969/03/23', 'F', 2, 'crfc23', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(1, 3, '40079441', 'ANGELA', 'MILENA', 'RODRIGUEZ', 'CARREÑO', '321 333 1791', 'CALLE 12 # 34 - 31', 'amrc10@gmail.com', '1968/04/10', 'F', 3, 'amrc10', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(4, 3, '1047667705', 'ANA', 'CRISTINA', 'MANCIPE', 'BECERRA', '322 730 6934', 'KRA 18 # 09 - 45', 'acmb20@gmail.com', '1988/09/20', 'F', 4, 'acmb20', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(1, 3, '40295629', 'WILSON', 'ANDRES', 'SEGURA', 'HUERTAS', '315 963 3120', 'TRANSV 3 # 34 - 21', 'wash5@gmail.com', '1970/10/14', 'M', 3, 'wash5', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(2, 3, '40761875', 'CESAR', 'ENRIQUE', 'FARFAN', 'FAGUA', '310 284 5380', 'KRA 15 # 13 - 23', 'ceff09@gmail.com', '1973/09/15', 'M', 3, 'ceff09', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(2, 3, '40606174', 'PILAR', 'ANDREA', 'VELANDIA', 'FAGUA', '319 715 8050', 'CALLE 15 # 13 - 23', 'pavf16@gmail.com', '1985/04/16', 'F', 3, 'pavf16', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(2, 3, '1047275137', 'AURA', 'NELY', 'BECERRA', 'TALERO', '310 495 8177', 'TRANSV 1 # 24 - 57', 'anbt19@gmail.com', '1990/10/19', 'F', 3, 'anbt19', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(4, 3, '1048840625', 'ANA', 'YAMILE', 'BOLIVAR', 'GOMEZ', '312 530 9640', 'CALLE 17 # 35 - 36', 'aybg20@gmail.com', '1992/02/20', 'F', 3, 'aybg20', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(4, 3, '1049605329', 'EDGAR', 'GIOVANY', 'RODRIGUEZ', 'ACUÑA', '319 366 1998', 'KRA 11 # 22 - 45', 'egra18@gmail.com', '1993/04/18', 'M', 4, 'egra18', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(4, 3, '1048700045', 'MARY', 'LUZ', 'ANGARITA', 'VALERO', '319 887 8843', 'CALLE 12 # 24 - 21', 'mlav45@gmail.com', '1989/07/11', 'F', 2, 'mlav45', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(2, 3, '1048615857', 'FLOR', 'EMILCE ', 'SILVA', 'HERNANDEZ', '315 212 3447', 'KRA 43 # 67 - 05', 'fesh7@gmail.com', '1993/03/28', 'F', 2, 'fesh7', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(2, 3, '1049910261', 'CLAUDIA', 'YANETH ', 'GRANADOS', 'PEDRAZA', '320 577 6574', 'CALLE 20 # 13 - 14', 'cygp3@gmail.com', '1991/09/23', 'F', 4, 'cygp3', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(3, 3, '1049333148', 'KARIMAR', 'YADIRA ', 'RODRIGUEZ', 'SUAREZ', '311 657 4754', 'KRA 15 # 25 - 26', 'kyrs8@gmail.com', '1990/08/04', 'F', 3, 'kyrs8', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(1, 3, '1048271264', 'YENNY', 'SUSANA ', 'HENAO', 'VARGAS', '320 954 8493', 'TRANSV 5 # 32 - 43', 'yshv87@gmail.com', '1987/02/27', 'F', 3, 'yshv87', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(1, 3, '1049143892', 'EDGAR', 'GIOVANY ', 'RODRIGUEZ', 'BOLIVAR', '314 106 4726', 'CALLE 17 # 10 - 35', 'egrb13@gmail.com', '1994/06/13', 'M', 3, 'egrb13', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(1, 3, '1049760337', 'BLANCA', 'YADIRA ', 'TALERO', 'ACUÑA', '311 412 6676', 'KRA 16 # 20 - 17', 'byta4@gmail.com', '1991/04/22', 'F', 3, 'byta4', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(1, 3, '1049702207', 'YENI', 'PAOLA', 'GRANADOS', 'MORENO', '315 839 8725', 'TRANSV 1 # 54 - 13', 'ypgm2@gmail.com', '1992/05/09', 'F', 3, 'ypgm2', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(4, 3, '1049370274', 'CARLOS', 'ESTEBAN', 'BARRERA', 'ROBAYO', '317 149 1076', 'CALLE 18 # 24 - 28', 'cebr1@gmail.com', '1990/06/08', 'M', 4, 'cebr1', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(4, 3, '1048490928', 'LEIDY', 'ROSALBA', 'DIAZ', 'SUAREZ', '318 903 8484', 'KRA 24 # 46 - 13', 'lrds6@gmail.com', '1989/06/23', 'F', 2, 'lrds6', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(4, 3, '1049060642', 'MARIA', 'CLAUDIA', 'PIRACOCA', 'DUARTE', '313 803 2703', 'TRANSV 3 # 24 - 11', 'mcpd4@gmail.com', '1988/10/04', 'F', 3, 'mcpd4', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(4, 3, '1048479989', 'YANETH', 'MILENA', 'GUTIERREZ', 'RAMIREZ', '310 540 1890', 'CALLE 30 # 11 - 17', 'ymgr6@gmail.com', '1987/04/20', 'F', 3, 'ymgr6', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(1, 3, '1049725720', 'DANIEL', 'STEWART', 'ALBA', 'AMEZQUITA', '313 485 5608', 'KRA 19 # 03 - 21', 'dsaa24@gmail.com', '1992/11/24', 'M', 2, 'dsaa24', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(1, 3, '1047692791', 'SANDRA', 'MILENA', 'SUAREZ', 'ALVAREZ', '317 916 8031', 'TRANSV 4 # 12 - 18', 'smsa11@gmail.com', '1986/11/01', 'F', 4, 'smsa11', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(2, 3, '1048725276', 'LILIA', 'ZORAIDA ', 'HIGUERA', 'GRANADOS', '310 845 2173', 'CALLE 32 # 15 - 42', 'lzhg3@gmail.com', '1989/03/03', 'F', 4, 'lzhg3', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(2, 3, '1049680512', 'DEISY', 'YINETH ', 'LOPEZ', 'VEGA', '320 651 3241', 'KRA 22 # 13 - 45', 'dmlv6@gmail.com', '1990/06/30', 'F', 2, 'dmlv6', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(3, 3, '1049488163', 'MARIA', 'AURORA ', 'MAYORGA', 'SAIZ', '311 865 9095', 'TRANSV 1 # 11 - 22', 'mams5@gmail.com', '1991/05/05', 'F', 3, 'mams5', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(3, 3, '1049829192', 'JOSE', 'DARIO', 'RIOS', 'RODRIGUEZ', '312 804 7055', 'CALLE 32 # 20 - 33', 'jdrr4@gmail.com', '1991/12/31', 'M', 2, 'jdrr4', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(2, 3, '1049993200', 'MARIA', 'ALEXANDRA', 'SUESCA', 'IBAÑEZ', '316 181 4198', 'KRA 10 # 11 - 15', 'masi2@gmail.com', '1993/12/02', 'F', 2, 'masi2', '12345');

INSERT INTO personas (id_estado_civil, id_perfil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, direccion, email, fecha_nacimiento, genero, estrato, nombre_usuario, clave)
VALUES(2, 3, '1048758885', 'INGRID', 'YOLANDA', 'AMAYA', 'CARDENAS', '310 508 7642', 'CALLE 15 # 24 - 05', 'iyac1@gmail.com', '1990/01/29', 'F', 4, 'iyac1', '12345');