/*=================== SCRIPT BASE VACUNAUTAS ===================*/

/*==============================================================*/
/* Tabla: vacunas                                               */
/*==============================================================*/
create table vacunas
(
   id_vacuna             bigint not null auto_increment  comment '',
   nombre_vacuna        varchar(100) not null  comment '',
   primary key (id_vacuna)
);

/*==============================================================*/
/* Tabla: laboratorios                                          */
/*==============================================================*/
create table laboratorios
(
   id_laboratorio        bigint not null auto_increment  comment '',
   nombre_lab           varchar(20) not null  comment '',
   primary key (id_laboratorio)
);

/*==============================================================*/
/* Tabla: rel_vacunas_laboratorios                              */
/*==============================================================*/
create table rel_vacunas_laboratorios
(
   id_rel_vac_lab        bigint not null auto_increment comment '',
   id_vacuna	            bigint not null  comment '',
   id_laboratorio        bigint not null  comment '',
   numero_lote          varchar(45) not null  comment '',
   primary key (id_rel_vac_lab)
);

/*==============================================================*/
/* Tabla: dosis                                                 */
/*==============================================================*/
create table dosis
(
   id_dosis              bigint not null auto_increment  comment '',
   nombre_dosis         varchar(25) not null  comment '',
   primary key (id_dosis)
);

/*==============================================================*/
/* Tabla: rel_vacunas_dosis                                     */
/*==============================================================*/
create table rel_vacunas_dosis
(
   id_rel_vac_dosis      bigint not null auto_increment comment '',
   id_vacuna	            bigint not null  comment '',
   id_dosis              bigint not null  comment '',
   primary key (id_rel_vac_dosis)
);

/*==============================================================*/
/* Tabla: vias_aplicacion                                       */
/*==============================================================*/
create table vias_aplicacion
(
   id_via                bigint not null auto_increment  comment '',
   nombre_via           varchar(45) not null  comment '',
   primary key (id_via)
);

/*==============================================================*/
/* Tabla: rel_vacunas_vias_aplicacion                           */
/*==============================================================*/
create table rel_vacunas_vias_aplicacion
(
   id_rel_vac_vias       bigint not null auto_increment comment '',
   id_vacuna	            bigint not null  comment '',
   id_via                bigint not null  comment '',
   primary key (id_rel_vac_vias)
);

/*==============================================================*/
/* Tabla: edades                                                */
/*==============================================================*/
create table edades
(
   id_edad              bigint not null auto_increment  comment '',
   edad                varchar(20) not null  comment '',
   primary key (id_edad)
);

/*==============================================================*/
/* Tabla: rel_vacunas_edades                                    */
/*==============================================================*/
create table rel_vacunas_edades
(
   id_rel_vac_edad       bigint not null auto_increment comment '',
   id_vacuna	            bigint not null  comment '',
   id_edad               bigint not null  comment '',
   primary key (id_rel_vac_edad)
);

/*==============================================================*/
/* Tabla: instituciones                                         */
/*==============================================================*/
create table instituciones
(
   id_institucion       bigint not null auto_increment  comment '',
   nombre_institucion  varchar(45) not null  comment '',
   primary key (id_institucion)
);

/*==============================================================*/
/* Tabla: estado_civil                                          */
/*==============================================================*/
create table estado_civil
(
   id_estado_civil      bigint not null auto_increment  comment '',
   descripcion         varchar(30) not null  comment '',
   primary key (id_estado_civil)
);

/*==============================================================*/
/* Tabla: enfermeras                                            */
/*==============================================================*/
create table enfermeras
(
   id_enfermera          bigint not null auto_increment comment '',
   id_estado_civil	    bigint not null  comment '',
   id_institucion        bigint not null  comment '',
   identificacion       varchar(30) not null  comment '',
   primer_nombre        varchar(20) not null  comment '',
   segundo_nombre       varchar(20)  comment '',
   primer_apellido      varchar(20)  comment '',
   segundo_apellido     varchar(20)  comment '',
   telefono             varchar(20)  comment '',
   celular              varchar(20) not null  comment '',
   direccion            varchar(45)  comment '',
   email                varchar(45)  comment '',
   fecha_nacimiento     date not null  comment '',
   genero               varchar(2)  comment '',
   estrato              smallint  comment '',
   titulo               varchar(70) not null  comment '',
   primary key (id_enfermera)
);

/*==============================================================*/
/* Tabla: ni�os                                                 */
/*==============================================================*/
create table ni�os
(
   id_ni�o               bigint not null auto_increment comment '',
   identificacion       varchar(30) not null  comment '',
   primer_nombre        varchar(20) not null  comment '',
   segundo_nombre       varchar(20)  comment '',
   primer_apellido      varchar(20) not null  comment '',
   segundo_apellido     varchar(20)  comment '',
   fecha_nacimiento     date not null  comment '',
   genero               varchar(2) not null  comment '',
   primary key (id_ni�o)
);

/*==============================================================*/
/* Tabla: acudientes                                            */
/*==============================================================*/
create table acudientes
(
   id_acudiente          bigint not null auto_increment comment '',
   id_estado_civil	    bigint not null  comment '',
   identificacion       varchar(30) not null  comment '',
   primer_nombre        varchar(20) not null  comment '',
   segundo_nombre       varchar(20)  comment '',
   primer_apellido      varchar(20)  comment '',
   segundo_apellido     varchar(20)  comment '',
   telefono             varchar(20)  comment '',
   celular              varchar(20) not null  comment '',
   direccion            varchar(45)  comment '',
   email                varchar(45)  comment '',
   fecha_nacimiento     date not null  comment '',
   genero               varchar(2)  comment '',
   estrato              smallint  comment '',
   primary key (id_acudiente)
);

/*==============================================================*/
/* Tabla: rel_ni�os_acudientes                                  */
/*==============================================================*/
create table rel_ni�os_acudientes
(
   id_rel_ni�o_acudiente   bigint not null auto_increment comment '',
   id_ni�o	              bigint not null  comment '',
   id_acudiente            bigint not null  comment '',
   parentezco             varchar(30) not null  comment '',
   primary key (id_rel_ni�o_acudiente)
);

/*==============================================================*/
/* Tabla: estados_vacunacion                                    */
/*==============================================================*/
create table estados_vacunacion
(
   id_estado_vacunacion   bigint not null auto_increment  comment '',
   estado                varchar(20) not null  comment '',
   primary key (id_estado_vacunacion)
);

/*==============================================================*/
/* Tabla: citas                                                 */
/*==============================================================*/
create table citas
(
   id_cita                 bigint not null auto_increment comment '',
   id_ni�o	              bigint not null  comment '',
   id_vacuna               bigint not null  comment '',
   id_estado_vacunacion    bigint not null  comment '',
   id_enfermera            bigint not null  comment '',
   fecha_cita             date  comment '',
   hora_aplicacion        time comment '',
   fecha_aplicacion       date  comment '',
   comentarios            varchar(300)  comment '',
   primary key (id_cita)
);

/*==============================================================*/
/* Llaves for�neas                                              */
/*==============================================================*/

alter table rel_vacunas_laboratorios add constraint fk_relvaclab_reference_laboratorios foreign key (id_laboratorio)
      references laboratorios (id_laboratorio) on delete restrict on update cascade;
	  
alter table rel_vacunas_laboratorios add constraint fk_relvaclab_reference_vacunas foreign key (id_vacuna)
      references vacunas (id_vacuna) on delete restrict on update cascade;

alter table rel_vacunas_dosis add constraint fk_relvacdosis_reference_dosis foreign key (id_dosis)
      references dosis (id_dosis) on delete restrict on update cascade;

alter table rel_vacunas_dosis add constraint fk_relvacdosis_reference_vacunas foreign key (id_vacuna)
      references vacunas (id_vacuna) on delete restrict on update cascade;
	  
alter table rel_vacunas_vias_aplicacion add constraint fk_relvacvias_reference_vias_aplicacion foreign key (id_via)
      references vias_aplicacion (id_via) on delete restrict on update cascade;
	  
alter table rel_vacunas_vias_aplicacion add constraint fk_relvacvias_reference_vacunas foreign key (id_vacuna)
      references vacunas (id_vacuna) on delete restrict on update cascade;
	  
alter table rel_vacunas_edades add constraint fk_relvacedades_reference_edades foreign key (id_edad)
      references edades (id_edad) on delete restrict on update cascade;
	  
alter table rel_vacunas_edades add constraint fk_relvacedades_reference_vacunas foreign key (id_vacuna)
      references vacunas (id_vacuna) on delete restrict on update cascade;
	  
alter table rel_ni�os_acudientes add constraint fk_relni�oacud_reference_acudientes foreign key (id_acudiente)
      references acudientes (id_acudiente) on delete restrict on update cascade;
	  
alter table rel_ni�os_acudientes add constraint fk_relni�oacud_reference_ni�os foreign key (id_ni�o)
      references ni�os (id_ni�o) on delete restrict on update cascade;
	  
alter table enfermeras add constraint fk_enfermeras_reference_estado_civil foreign key (id_estado_civil)
      references estado_civil (id_estado_civil) on delete restrict on update cascade;
	  
alter table enfermeras add constraint fk_enfermeras_reference_instituciones foreign key (id_institucion)
      references instituciones (id_institucion) on delete restrict on update cascade;
	  
alter table acudientes add constraint fk_acudientes_reference_estado_civil foreign key (id_estado_civil)
      references estado_civil (id_estado_civil) on delete restrict on update cascade;
	  
alter table citas add constraint fk_citas_reference_ni�os foreign key (id_ni�o)
      references ni�os (id_ni�o) on delete restrict on update cascade;
	  
alter table citas add constraint fk_citas_reference_vacunas foreign key (id_vacuna)
      references vacunas (id_vacuna) on delete restrict on update cascade;
	  
alter table citas add constraint fk_citas_reference_estados_vacunacion foreign key (id_estado_vacunacion)
      references estados_vacunacion (id_estado_vacunacion) on delete restrict on update cascade;
	  
alter table citas add constraint fk_citas_reference_enfermeras foreign key (id_enfermera)
      references enfermeras (id_enfermera) on delete restrict on update cascade;
