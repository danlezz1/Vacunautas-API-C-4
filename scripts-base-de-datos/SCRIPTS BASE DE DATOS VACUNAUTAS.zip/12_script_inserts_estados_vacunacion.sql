INSERT INTO estados_vacunacion (estado)
VALUES('APLICADA');

INSERT INTO estados_vacunacion (estado)
VALUES('NO APLICADA');

INSERT INTO estados_vacunacion (estado)
VALUES('SIN APLICAR');

INSERT INTO estados_vacunacion (estado)
VALUES('PROGRAMADA');