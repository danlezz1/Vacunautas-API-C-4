INSERT INTO vacunas (nombre_vacuna)
VALUES('Tuberculosis B.C.G');

INSERT INTO vacunas (nombre_vacuna)
VALUES('Hepatitis B');

INSERT INTO vacunas (nombre_vacuna)
VALUES('Polio');

INSERT INTO vacunas (nombre_vacuna)
VALUES('PENTAVALENTE: Hepatitis B, Haemophilus Influenzae Tipo b y Difteria - Tosferina - Tetáno (DPT)');

INSERT INTO vacunas (nombre_vacuna)
VALUES('Rotavirus');

INSERT INTO vacunas (nombre_vacuna)
VALUES('Neumococo');

INSERT INTO vacunas (nombre_vacuna)
VALUES('Influenza');

INSERT INTO vacunas (nombre_vacuna)
VALUES('Sarampión Rubéola Paperas (SRP)');

INSERT INTO vacunas (nombre_vacuna)
VALUES('Fiebre Amarilla');

INSERT INTO vacunas (nombre_vacuna)
VALUES('Varicela');