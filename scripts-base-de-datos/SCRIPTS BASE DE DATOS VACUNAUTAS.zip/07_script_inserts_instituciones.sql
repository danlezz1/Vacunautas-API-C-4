INSERT INTO instituciones (nombre_institucion)
VALUES('HOSPITAL BICENTENARIO');

INSERT INTO instituciones (nombre_institucion)
VALUES('HOSPITAL CENTRAL');

INSERT INTO instituciones (nombre_institucion)
VALUES('HOSPITAL NIEVES');

INSERT INTO instituciones (nombre_institucion)
VALUES('CLÍNICA MUISCA');

INSERT INTO instituciones (nombre_institucion)
VALUES('HOSPITAL SAN RAFAEL');

INSERT INTO instituciones (nombre_institucion)
VALUES('CLÍNICA MEDILÁSER');