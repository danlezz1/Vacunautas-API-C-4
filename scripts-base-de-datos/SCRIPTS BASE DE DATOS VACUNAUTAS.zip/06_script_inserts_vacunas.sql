INSERT INTO vacunas (nombre_vacuna, id_dosis, id_edad, id_via)
VALUES('Tuberculosis B.C.G', 1, 1, 5);

INSERT INTO vacunas (nombre_vacuna, id_dosis, id_edad, id_via)
VALUES('Hepatitis B', 2, 1, 5);

INSERT INTO vacunas (nombre_vacuna, id_dosis, id_edad, id_via)
VALUES('Polio', 3, 2, 5);

INSERT INTO vacunas (nombre_vacuna, id_dosis, id_edad, id_via)
VALUES('PENTAVALENTE: Hepatitis B, Haemophilus Influenzae Tipo b y Difteria - Tosferina - Tetáno (DPT)', 3, 2, 5);

INSERT INTO vacunas (nombre_vacuna, id_dosis, id_edad, id_via)
VALUES('Rotavirus', 3, 2, 5);

INSERT INTO vacunas (nombre_vacuna, id_dosis, id_edad, id_via)
VALUES('Neumococo', 3, 2, 5);

INSERT INTO vacunas (nombre_vacuna, id_dosis, id_edad, id_via)
VALUES('Influenza', 3, 4, 5);

INSERT INTO vacunas (nombre_vacuna, id_dosis, id_edad, id_via)
VALUES('Sarampión Rubéola Paperas (SRP)', 3, 6, 5);

INSERT INTO vacunas (nombre_vacuna, id_dosis, id_edad, id_via)
VALUES('Fiebre Amarilla', 1, 7, 5);

INSERT INTO vacunas (nombre_vacuna, id_dosis, id_edad, id_via)
VALUES('Varicela', 4, 6, 5);