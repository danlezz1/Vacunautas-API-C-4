INSERT INTO perfiles (nombre_perfil)
VALUES('ADMINISTRADOR');

INSERT INTO perfiles (nombre_perfil)
VALUES('ENFERMERA');

INSERT INTO perfiles (nombre_perfil)
VALUES('ACUDIENTE');