INSERT INTO acudientes (id_estado_civil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato)
VALUES(2, '40511119', 'ELDA', 'JOHANA', 'PEDRAZA', 'AMEZQUITA', '7468560', '314 516 2170', 'KRA 11 # 23 - 65', 'ejpa1@gmail.com', '1980/11/01', 'F', 2);

INSERT INTO acudientes (id_estado_civil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato)
VALUES(1, '40213134', 'CARMEN', 'ROSA', 'FONSECA', 'CANO', '7432934', '311 506 3539', 'CALLE 2 # 11 - 34', 'crfc23@gmail.com', '1969/03/23', 'F', 2);

INSERT INTO acudientes (id_estado_civil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato)
VALUES(1, '40079441', 'ANGELA', 'MILENA', 'RODRIGUEZ', 'CARREÑO', '7416499', '321 333 1791', 'CALLE 12 # 34 - 31', 'amrc10@gmail.com', '1968/04/10', 'F', 3);

INSERT INTO acudientes (id_estado_civil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato)
VALUES(4, '1047667705', 'ANA', 'CRISTINA', 'MANCIPE', 'BECERRA', '7468512', '322 730 6934', 'KRA 18 # 09 - 45', 'acmb20@gmail.com', '1988/09/20', 'F', 4);

INSERT INTO acudientes (id_estado_civil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato)
VALUES(1, '40295629', 'WILSON', 'ANDRES', 'SEGURA', 'HUERTAS', '7438554', '315 963 3120', 'TRANSV 3 # 34 - 21', 'wash5@gmail.com', '1970/10/14', 'M', 3);

INSERT INTO acudientes (id_estado_civil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato)
VALUES(2, '40761875', 'CESAR', 'ENRIQUE', 'FARFAN', 'FAGUA', '7423274', '310 284 5380', 'KRA 15 # 13 - 23', 'ceff09@gmail.com', '1973/09/15', 'M', 3);

INSERT INTO acudientes (id_estado_civil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato)
VALUES(2, '40606174', 'PILAR', 'ANDREA', 'VELANDIA', 'FAGUA', '7438728', '319 715 8050', 'CALLE 15 # 13 - 23', 'pavf16@gmail.com', '1985/04/16', 'F', 3);

INSERT INTO acudientes (id_estado_civil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato)
VALUES(2, '1047275137', 'AURA', 'NELY', 'BECERRA', 'TALERO', '7465666', '310 495 8177', 'TRANSV 1 # 24 - 57', 'anbt19@gmail.com', '1990/10/19', 'F', 3);

INSERT INTO acudientes (id_estado_civil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato)
VALUES(4, '1048840625', 'ANA', 'YAMILE', 'BOLIVAR', 'GOMEZ', '7454913', '312 530 9640', 'CALLE 17 # 35 - 36', 'aybg20@gmail.com', '1992/02/20', 'F', 3);

INSERT INTO acudientes (id_estado_civil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato)
VALUES(4, '1049605329', 'EDGAR', 'GIOVANY', 'RODRIGUEZ', 'ACUÑA', '7436062', '319 366 1998', 'KRA 11 # 22 - 45', 'egra18@gmail.com', '1993/04/18', 'M', 4);

INSERT INTO acudientes (id_estado_civil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato)
VALUES(4, '1048700045', 'MARY', 'LUZ', 'ANGARITA', 'VALERO', '7438595', '319 887 8843', 'CALLE 12 # 24 - 21', 'mlav45@gmail.com', '1989/07/11', 'F', 2);

INSERT INTO acudientes (id_estado_civil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato)
VALUES(2, '1048615857', 'FLOR', 'EMILCE ', 'SILVA', 'HERNANDEZ', '7462439', '315 212 3447', 'KRA 43 # 67 - 05', 'fesh7@gmail.com', '1993/03/28', 'F', 2);

INSERT INTO acudientes (id_estado_civil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato)
VALUES(2, '1049910261', 'CLAUDIA', 'YANETH ', 'GRANADOS', 'PEDRAZA', '7447288', '320 577 6574', 'CALLE 20 # 13 - 14', 'cygp3@gmail.com', '1991/09/23', 'F', 4);

INSERT INTO acudientes (id_estado_civil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato)
VALUES(3, '1049333148', 'KARIMAR', 'YADIRA ', 'RODRIGUEZ', 'SUAREZ', '7452086', '311 657 4754', 'KRA 15 # 25 - 26', 'kyrs8@gmail.com', '1990/08/04', 'F', 3);

INSERT INTO acudientes (id_estado_civil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato)
VALUES(1, '1048271264', 'YENNY', 'SUSANA ', 'HENAO', 'VARGAS', '7470575', '320 954 8493', 'TRANSV 5 # 32 - 43', 'yshv87@gmail.com', '1987/02/27', 'F', 3);

INSERT INTO acudientes (id_estado_civil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato)
VALUES(1, '1049143892', 'EDGAR', 'GIOVANY ', 'RODRIGUEZ', 'BOLIVAR', '7435663', '314 106 4726', 'CALLE 17 # 10 - 35', 'egrb13@gmail.com', '1994/06/13', 'M', 3);

INSERT INTO acudientes (id_estado_civil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato)
VALUES(1, '1049760337', 'BLANCA', 'YADIRA ', 'TALERO', 'ACUÑA', '7471558', '311 412 6676', 'KRA 16 # 20 - 17', 'byta4@gmail.com', '1991/04/22', 'F', 3);

INSERT INTO acudientes (id_estado_civil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato)
VALUES(1, '1049702207', 'YENI', 'PAOLA', 'GRANADOS', 'MORENO', '7427948', '315 839 8725', 'TRANSV 1 # 54 - 13', 'ypgm2@gmail.com', '1992/05/09', 'F', 3);

INSERT INTO acudientes (id_estado_civil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato)
VALUES(4, '1049370274', 'CARLOS', 'ESTEBAN', 'BARRERA', 'ROBAYO', '7468625', '317 149 1076', 'CALLE 18 # 24 - 28', 'cebr1@gmail.com', '1990/06/08', 'M', 4);

INSERT INTO acudientes (id_estado_civil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato)
VALUES(4, '1048490928', 'LEIDY', 'ROSALBA', 'DIAZ', 'SUAREZ', '7475070', '318 903 8484', 'KRA 24 # 46 - 13', 'lrds6@gmail.com', '1989/06/23', 'F', 2);

INSERT INTO acudientes (id_estado_civil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato)
VALUES(4, '1049060642', 'MARIA', 'CLAUDIA', 'PIRACOCA', 'DUARTE', '7403960', '313 803 2703', 'TRANSV 3 # 24 - 11', 'mcpd4@gmail.com', '1988/10/04', 'F', 3);

INSERT INTO acudientes (id_estado_civil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato)
VALUES(4, '1048479989', 'YANETH', 'MILENA', 'GUTIERREZ', 'RAMIREZ', '7448980', '310 540 1890', 'CALLE 30 # 11 - 17', 'ymgr6@gmail.com', '1987/04/20', 'F', 3);

INSERT INTO acudientes (id_estado_civil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato)
VALUES(1, '1049725720', 'DANIEL', 'STEWART', 'ALBA', 'AMEZQUITA', '7466667', '313 485 5608', 'KRA 19 # 03 - 21', 'dsaa24@gmail.com', '1992/11/24', 'M', 2);

INSERT INTO acudientes (id_estado_civil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato)
VALUES(1, '1047692791', 'SANDRA', 'MILENA', 'SUAREZ', 'ALVAREZ', '7414842', '317 916 8031', 'TRANSV 4 # 12 - 18', 'smsa11@gmail.com', '1986/11/01', 'F', 4);

INSERT INTO acudientes (id_estado_civil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato)
VALUES(2, '1048725276', 'LILIA', 'ZORAIDA ', 'HIGUERA', 'GRANADOS', '7445090', '310 845 2173', 'CALLE 32 # 15 - 42', 'lzhg3@gmail.com', '1989/03/03', 'F', 4);

INSERT INTO acudientes (id_estado_civil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato)
VALUES(2, '1049680512', 'DEISY', 'YINETH ', 'LOPEZ', 'VEGA', '7413925', '320 651 3241', 'KRA 22 # 13 - 45', 'dmlv6@gmail.com', '1990/06/30', 'F', 2);

INSERT INTO acudientes (id_estado_civil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato)
VALUES(3, '1049488163', 'MARIA', 'AURORA ', 'MAYORGA', 'SAIZ', '7479037', '311 865 9095', 'TRANSV 1 # 11 - 22', 'mams5@gmail.com', '1991/05/05', 'F', 3);

INSERT INTO acudientes (id_estado_civil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato)
VALUES(3, '1049829192', 'JOSE', 'DARIO', 'RIOS', 'RODRIGUEZ', '7467082', '312 804 7055', 'CALLE 32 # 20 - 33', 'jdrr4@gmail.com', '1991/12/31', 'M', 2);

INSERT INTO acudientes (id_estado_civil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato)
VALUES(2, '1049993200', 'MARIA', 'ALEXANDRA', 'SUESCA', 'IBAÑEZ', '7416217', '316 181 4198', 'KRA 10 # 11 - 15', 'masi2@gmail.com', '1993/12/02', 'F', 2);

INSERT INTO acudientes (id_estado_civil, identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, telefono, celular, direccion, email, fecha_nacimiento, genero, estrato)
VALUES(2, '1048758885', 'INGRID', 'YOLANDA', 'AMAYA', 'CARDENAS', '7469509', '310 508 7642', 'CALLE 15 # 24 - 05', 'iyac1@gmail.com', '1990/01/29', 'F', 4);