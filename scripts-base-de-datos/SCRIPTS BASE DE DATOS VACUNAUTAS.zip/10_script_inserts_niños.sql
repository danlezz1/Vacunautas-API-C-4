INSERT INTO niños (identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, fecha_nacimiento, genero)
VALUES('1090057038', 'DANIEL', 'SANTIAGO', 'GONZALEZ', 'PEDRAZA', '2018/09/22', 'M');

INSERT INTO niños (identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, fecha_nacimiento, genero)
VALUES('1090064417', 'LICETH', 'ALEJANDRA', 'FONSECA', 'CANO', '2018/10/11', 'F');

INSERT INTO niños (identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, fecha_nacimiento, genero)
VALUES('1090088521', 'MAICOL', 'YESSID', 'REYES', 'RODRIGUEZ', '2019/01/22', 'M');

INSERT INTO niños (identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, fecha_nacimiento, genero)
VALUES('1090138900', 'DIANA', 'CATALINA', 'CANO', 'MANCIPE', '2019/05/16', 'F');

INSERT INTO niños (identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, fecha_nacimiento, genero)
VALUES('1090095551', 'STIVEN', 'SANTIAGO', 'SEGURA', 'HUERTAS', '2019/01/26', 'M');

INSERT INTO niños (identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, fecha_nacimiento, genero)
VALUES('1090144905', 'THOMAS', 'FELIPE', 'FARFAN', 'GOMEZ', '2019/09/17', 'M');

INSERT INTO niños (identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, fecha_nacimiento, genero)
VALUES('1090173895', 'KAREN', 'SOFIA', 'ANGARITA', 'VELANDIA', '2019/07/03', 'F');

INSERT INTO niños (identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, fecha_nacimiento, genero)
VALUES('1090101909', 'YEISON', 'FERNANDO', 'BECERRA', 'BECERRA', '2019/04/25', 'M');

INSERT INTO niños (identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, fecha_nacimiento, genero)
VALUES('1090189811', 'JAIDER', 'YAMITH', 'PIRACOCA', 'BOLIVAR', '2019/12/02', 'M');

INSERT INTO niños (identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, fecha_nacimiento, genero)
VALUES('1090305664', 'JOHAN', 'SANTIAGO', 'RODRIGUEZ', 'RAMIREZ', '2020/01/21', 'M');

INSERT INTO niños (identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, fecha_nacimiento, genero)
VALUES('1090281081', 'SAMUEL', 'ESTEBAN', 'MORENO', 'ANGARITA', '2020/01/07', 'M');

INSERT INTO niños (identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, fecha_nacimiento, genero)
VALUES('1090153104', 'MAILY', 'DAYANA', 'SAENZ', 'SILVA', '2019/07/28', 'F');

INSERT INTO niños (identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, fecha_nacimiento, genero)
VALUES('1090180505', 'DIANA', 'ALEXANDRA', 'ROJAS', 'GRANADOS', '2019/10/26', 'F');

INSERT INTO niños (identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, fecha_nacimiento, genero)
VALUES('1090219772', 'BRAYAN', 'ALEXIS', 'RODRIGUEZ', 'RODRIGUEZ', '2019/12/03', 'M');

INSERT INTO niños (identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, fecha_nacimiento, genero)
VALUES('1090353776', 'JHONATHAN', 'ALEJANDRO', 'HENAO', 'VARGAS', '2020/04/07', 'M');

INSERT INTO niños (identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, fecha_nacimiento, genero)
VALUES('1090410211', 'EDUAR', 'STEBAN', 'RODRIGUEZ', 'DUARTE', '2020/06/04', 'M');

INSERT INTO niños (identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, fecha_nacimiento, genero)
VALUES('1090379366', 'SILVIA', 'MARIA', 'CIFUENTES', 'TALERO', '2020/04/05', 'F');

INSERT INTO niños (identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, fecha_nacimiento, genero)
VALUES('1090427114', 'SEBASTIAN', 'DAVID', 'ROJAS', 'GRANADOS', '2020/07/23', 'M');

INSERT INTO niños (identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, fecha_nacimiento, genero)
VALUES('1090343885', 'ANGELA', 'MARIA', 'BARRERA', 'MEDINA', '2020/02/27', 'F');

INSERT INTO niños (identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, fecha_nacimiento, genero)
VALUES('1090295751', 'EDISON', 'ANDRES', 'FONSECA', 'DIAZ', '2019/12/16', 'M');

INSERT INTO niños (identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, fecha_nacimiento, genero)
VALUES('1090403714', 'JULIAN', 'ESNEIDER', 'LEON', 'PIRACOCA', '2020/04/06', 'M');

INSERT INTO niños (identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, fecha_nacimiento, genero)
VALUES('1090330031', 'EMANUEL', 'ADNER', 'GUTIERREZ', 'HURTADO', '2020/01/21', 'M');

INSERT INTO niños (identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, fecha_nacimiento, genero)
VALUES('1090403851', 'SARA', 'VALENTINA', 'ALBA', 'AMEZQUITA', '2020/05/03', 'F');

INSERT INTO niños (identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, fecha_nacimiento, genero)
VALUES('1090465608', 'EDUARD', 'DAVID', 'GONZALEZ', 'SUAREZ', '2021/01/22', 'M');

INSERT INTO niños (identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, fecha_nacimiento, genero)
VALUES('1090481257', 'YENNYED', 'ALEXANDRA', 'PACHECO', 'HIGUERA', '2021/03/12', 'F');

INSERT INTO niños (identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, fecha_nacimiento, genero)
VALUES('1090461372', 'SHARON', 'NIKOL', 'SAIZ', 'LOPEZ', '2020/12/10', 'F');

INSERT INTO niños (identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, fecha_nacimiento, genero)
VALUES('1090447818', 'KEVIN', 'ALEJANDRO', 'SANCHEZ', 'MAYORGA', '2020/11/01', 'M');

INSERT INTO niños (identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, fecha_nacimiento, genero)
VALUES('1090515535', 'JUAN', 'SEBASTIAN', 'RIOS', 'SUAREZ', '2021/04/16', 'M');

INSERT INTO niños (identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, fecha_nacimiento, genero)
VALUES('1090524145', 'ANA', 'LIZETH', 'FAGUA', 'SUESCA', '2021/06/23', 'F');

INSERT INTO niños (identificacion, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, fecha_nacimiento, genero)
VALUES('1090534618', 'GERALDINE', 'XIMENA', 'FIGUEREDO', 'AMAYA', '2021/08/04', 'F');
